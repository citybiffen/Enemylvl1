# EnemyReleveler
A Mutagen patcher that lets you configure the levels of NPCs according to their type for a truly deleveled Skyrim. 
Inspired by the original patcher by tjhm4 (https://www.nexusmods.com/skyrimspecialedition/mods/32211)
